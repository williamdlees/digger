# Make probability tables for selected features from features.csv

import csv
from collections import defaultdict
import random


def random_seq(length):
    bases = ['A', 'C', 'G', 'T']
    ret = ''
    for i in range(length):
        ret += bases[random.randrange(4)]
    return ret


def calc_matrices():
    with open('features.csv', 'r') as fi:
        reader = csv.DictReader(fi)
        feature_rows = list(reader)

        gene_num = 1
        for feature_name in ["J-HEPTAMER", "J-NONAMER", "5'D-HEPTAMER", "5'D-NONAMER", "3'D-HEPTAMER", "3'D-NONAMER", 'L-PART1', 'L-PART2', "V-HEPTAMER", "V-NONAMER"]:
            seqs = {}
            for feature_row in feature_rows:
                if feature_row['feature'] == feature_name and len(feature_row['seq']) > 0 and len(feature_row['pseudo'])== 0:
                    gene_name = feature_row['gene'] if feature_row['gene'] else str(gene_num)
                    gene_num += 1
                    seqs[gene_name] = feature_row['seq'].upper()

            seqs = seqs.values()

            if len(seqs) == 0:
                continue

            lengths = defaultdict(int)
            for seq in seqs:
                lengths[len(seq)] += 1
            max_count = max(lengths.values())
            maj_length = 0
            for k, v in lengths.items():
                if v == max_count:
                    maj_length = k
                    break

            seqs = [list(s) for s in seqs if len(s) == maj_length]
            matrix = Motif(seqs)
            print('%s    %s    %0.4f    %s    %0.2f' % (feature_name, matrix.consensus, matrix.consensus_prob, matrix.conserved_consensus, matrix.calc_prob(matrix.conserved_consensus)))

            probs = []
            length = len(matrix.consensus)
            for i in range(10000):
                probs.append(matrix.calc_prob(random_seq(length))/matrix.consensus_prob)

            probs.sort()
            matrix.likelihood_threshold = probs[int(len(probs)*0.95)]
            print('5pc cutoff: %.2E' % matrix.likelihood_threshold)

            with open(feature_name + '_prob.csv', 'w', newline='') as fo:
                matrix.write_prob_matrix(fo)


class Motif:
    def __init__(self, seqs=None, stream=None):
        self.matrix = []
        self.consensus = None
        self.conserved_consensus = None
        self.consensus_prob = None
        self.likelihood_threshold = None

        if seqs is not None:
            self.calc_prob_matrix(seqs)
        elif stream is not None:
            self.read_prob_matrix(stream)

    def calc_update(self):
        self.calc_consensus()
        self.consensus_prob = self.calc_prob(self.consensus)
        self.calc_conserved_consensus()

    def calc_prob_matrix(self, seqs):
        al = zip(*seqs)

        self.matrix = []
        for z in al:
            pseudo = min(len(seqs)/10, 1)
            dist = {'A': pseudo, 'C': pseudo, 'G': pseudo, 'T': pseudo}  # inc. pseudocount
            total = 4*pseudo
            for base in z:
                if base in ['A', 'C', 'G', 'T']:
                    dist[base] += 1.0
                    total += 1
            for base in ['A', 'C', 'G', 'T']:
                dist[base] = dist[base]/total
            dist_sum = 0
            for base in ['A', 'C', 'G', 'T']:
                dist_sum += dist[base]
            if dist_sum < 0.99 or dist_sum > 1.01:
                print('error in pcm calc')
            self.matrix.append(dist)
        self.calc_update()

    def write_prob_matrix(self, fo):
        fo.write('%.6E\n' % self.likelihood_threshold)
        writer = csv.writer(fo)
        writer.writerow(['A', 'C', 'G', 'T'])
        for row in self.matrix:
            writer.writerow([round(row[base], 4) for base in ['A', 'C', 'G', 'T']])

    def read_prob_matrix(self, fi):
        self.likelihood_threshold = float(fi.readline().replace('\n', ''))
        reader = csv.DictReader(fi)
        self.matrix = list(reader)
        for row in self.matrix:
            for k,v in row.items():
                row[k] = float(v)
        self.calc_update()

    def calc_consensus(self):
        self.consensus = ''
        for row in self.matrix:
            c_pos = None
            c_prob = 0.0
            for base in ['A', 'C', 'G', 'T']:
                if row[base] > c_prob:
                    c_prob = row[base]
                    c_pos = base
            self.consensus += c_pos if c_pos is not None else '-'

    def calc_conserved_consensus(self):
        self.conserved_consensus = ''
        for row in self.matrix:
            c_pos = None
            for base in ['A', 'C', 'G', 'T']:
                if row[base] >= 0.75:
                    c_pos = base
                    break
            self.conserved_consensus += c_pos if c_pos is not None else '-'

    def calc_prob(self, seq):
        prob = 1.0
        for b, m in zip(list(seq),self.matrix):
            if b in m:
                prob = prob * m[b]
        return prob

    def calc_likelihood(self, seq):
        return self.calc_prob(seq) / self.consensus_prob


if __name__ == "__main__":
    calc_matrices()

