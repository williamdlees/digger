# Digger
A toolkit for the automatic annotation of V,D and J genes and associated features in IG receptor genomic loci.

For more details, please see the [documentation](https://williamdlees.github.io/digger/index.html).

